"""
models/probability.py
─────────────────────
Poisson-based live probability estimation for sports events.
Compares estimated true probability vs Polymarket's quoted price
to find exploitable edges.
"""

import math
from dataclasses import dataclass
from scipy.stats import poisson
from typing import Optional


@dataclass
class EdgeResult:
    market_id: str
    outcome: str                  # "yes" or "no"
    market_price: float           # Polymarket's current price (0-1)
    true_probability: float       # Our model's estimate (0-1)
    edge: float                   # true_prob - market_price
    kelly_fraction: float         # Recommended bet fraction
    confidence: str               # "high" / "medium" / "low"
    reasoning: str                # Human-readable explanation


def poisson_goal_probability(
    home_xg: float,
    away_xg: float,
    elapsed_minutes: int,
    total_minutes: int = 90,
    current_home_goals: int = 0,
    current_away_goals: int = 0,
) -> dict:
    """
    Estimate in-play goal probabilities using Poisson distribution.
    
    Uses remaining expected goals based on match state and elapsed time.
    Returns probabilities for: home_win, draw, away_win, over_2_5, btts.
    """
    remaining_fraction = max(0, (total_minutes - elapsed_minutes) / total_minutes)
    
    # Scale xG to remaining time
    remaining_home_xg = home_xg * remaining_fraction
    remaining_away_xg = away_xg * remaining_fraction

    # Calculate goal probabilities for each scoreline
    max_goals = 8
    home_probs = [poisson.pmf(g, remaining_home_xg) for g in range(max_goals)]
    away_probs = [poisson.pmf(g, remaining_away_xg) for g in range(max_goals)]

    p_home_win = 0.0
    p_draw = 0.0
    p_away_win = 0.0
    p_over_2_5 = 0.0
    p_btts = 0.0

    for h in range(max_goals):
        for a in range(max_goals):
            p = home_probs[h] * away_probs[a]
            final_h = current_home_goals + h
            final_a = current_away_goals + a

            if final_h > final_a:
                p_home_win += p
            elif final_h == final_a:
                p_draw += p
            else:
                p_away_win += p

            if (final_h + final_a) > 2.5:
                p_over_2_5 += p

            if final_h > 0 and final_a > 0:
                p_btts += p

    return {
        "home_win": round(p_home_win, 4),
        "draw":     round(p_draw, 4),
        "away_win": round(p_away_win, 4),
        "over_2_5": round(p_over_2_5, 4),
        "btts":     round(p_btts, 4),
    }


def basketball_win_probability(
    home_score: int,
    away_score: int,
    seconds_remaining: int,
    possession: Optional[str] = None,  # "home" or "away"
) -> dict:
    """
    Simple log5 + points-per-possession model for basketball.
    Uses historical average ~1.1 points per possession, ~60 possessions/half.
    """
    if seconds_remaining <= 0:
        if home_score > away_score:
            return {"home_win": 1.0, "away_win": 0.0}
        elif away_score > home_score:
            return {"home_win": 0.0, "away_win": 1.0}
        else:
            return {"home_win": 0.5, "away_win": 0.5}  # OT simplified

    point_diff = home_score - away_score
    # Empirical: ~0.03 std dev per second remaining in NBA
    std = 0.03 * math.sqrt(seconds_remaining)
    
    # Possession adjustment
    possession_bonus = 0.0
    if possession == "home":
        possession_bonus = 0.5
    elif possession == "away":
        possession_bonus = -0.5

    z = (point_diff + possession_bonus) / std if std > 0 else 0
    
    # Normal CDF approximation
    p_home_win = _normal_cdf(z)

    return {
        "home_win": round(p_home_win, 4),
        "away_win": round(1 - p_home_win, 4),
    }


def find_edge(
    market_id: str,
    market_price: float,
    true_probability: float,
    outcome: str,
    min_edge: float = 0.04,
    max_kelly: float = 0.06,
    reasoning: str = "",
) -> Optional[EdgeResult]:
    """
    Compare model probability vs market price.
    Returns EdgeResult if edge exceeds threshold, else None.
    """
    edge = true_probability - market_price

    if edge < min_edge:
        return None

    # Kelly fraction: edge / odds
    # For binary market at price p, odds = (1-p)/p
    if market_price <= 0 or market_price >= 1:
        return None

    odds = (1 - market_price) / market_price
    kelly = edge / odds
    kelly = min(kelly, max_kelly)  # cap at max

    confidence = "high" if edge > 0.10 else ("medium" if edge > 0.06 else "low")

    return EdgeResult(
        market_id=market_id,
        outcome=outcome,
        market_price=market_price,
        true_probability=true_probability,
        edge=round(edge, 4),
        kelly_fraction=round(kelly, 4),
        confidence=confidence,
        reasoning=reasoning,
    )


def _normal_cdf(x: float) -> float:
    """Abramowitz & Stegun approximation of normal CDF."""
    t = 1 / (1 + 0.2316419 * abs(x))
    d = 0.3989423 * math.exp(-x * x / 2)
    p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.7814779 + t * (-1.8212560 + t * 1.3302744))))
    return 1 - p if x > 0 else p
