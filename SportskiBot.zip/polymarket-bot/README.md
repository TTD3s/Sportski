# Polymarket Sports Latency Bot

Live sports latency arbitrage bot for Polymarket.  
Exploits the ~10-20s gap between sports API updates and Polymarket oracle price updates.

---

## How It Works

```
SportsRadar API (1-2s latency)
        ↓
  Live game event detected (goal, score change)
        ↓
  Poisson/probability model recalculates true odds
        ↓
  Compare vs Polymarket's current price (still stale)
        ↓
  Edge found → Kelly criterion sizing → Telegram alert
        ↓
  You approve (or auto-trade) → FOK order placed
```

## Setup (15 minutes)

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Get your API keys

**Telegram Bot (free, 5 min)**
1. Open Telegram → search `@BotFather`
2. Send `/newbot` → follow prompts
3. Copy the token
4. Start your bot, then visit: `https://api.telegram.org/bot<TOKEN>/getUpdates`
5. Send any message to the bot, refresh the URL — copy your `chat_id`

**SportsRadar (free trial)**
1. Sign up: https://developer.sportradar.com
2. Create a new app — select **Soccer Trial v4** and **NBA Trial v8**
3. Copy your API key

**Polymarket (wallet required)**
1. Connect MetaMask at https://polymarket.com
2. Profile → API Keys → Generate
3. Copy key, secret, and passphrase

### 3. Configure
```bash
cp .env.example .env
# Edit .env with your keys
```

### 4. Run in paper trading mode (default)
```bash
python main.py
```
`PAPER_TRADING = True` in `config.py` by default. No real money until you flip it.

---

## Telegram Commands

| Command | Action |
|---------|--------|
| `/status` | Bot state, mode, pending signals |
| `/pnl` | Portfolio summary, win rate, ROI |
| `/trades` | Last 5 closed trades |
| `/pause` | Pause signal detection |
| `/resume` | Resume detection |
| `/auto` | Auto-execute all signals (risky) |
| `/manual` | Manual approval per trade (default) |

---

## Strategy Details

### Edge Detection
- Soccer: Poisson distribution on remaining expected goals
- Basketball: Log5 + points-per-possession model
- Minimum edge: **4%** (market price vs true probability)
- Signal expires: **8 seconds** after detection

### Position Sizing (Kelly Criterion)
```
kelly_fraction = edge / odds
bet_size = bankroll × kelly_fraction
```
Capped at **6% of bankroll** per bet. Hard limits: $1 min, $50 max.

### Key parameters (config.py)
```python
MIN_EDGE_THRESHOLD = 0.04   # 4% minimum edge
MAX_KELLY_FRACTION = 0.06   # 6% max per bet
EDGE_WINDOW_SECONDS = 8     # act within 8s or skip
PRICE_STALE_THRESHOLD = 15  # skip stale Polymarket prices
```

---

## Deployment

### Local (testing)
```bash
python main.py
```

### AWS EC2 (recommended for <5ms latency to Polymarket)
```bash
# us-east-1 region (Polymarket CLOB is in Virginia)
# t3.small instance ~$15/month is sufficient

# Install
git clone <your-repo>
cd polymarket-bot
pip install -r requirements.txt
cp .env.example .env && nano .env

# Run persistently
pip install supervisor
# Add to supervisor config, then:
supervisorctl start polymarket-bot
```

### Railway / Render (easiest)
1. Push to GitHub
2. Connect repo to Railway/Render
3. Add env vars in dashboard
4. Deploy

---

## Files

```
polymarket-bot/
├── main.py                 # Entry point
├── config.py               # All settings
├── requirements.txt
├── .env.example
├── core/
│   ├── sports_feed.py      # SportsRadar poller
│   ├── polymarket.py       # WS + REST client
│   ├── edge_detector.py    # Core signal logic
│   └── portfolio.py        # Trade tracking + P&L
├── models/
│   └── probability.py      # Poisson + Kelly models
└── telegram/
    └── bot.py              # Telegram interface
```

---

## Important Notes

- Start with **paper trading** (default). Run for at least 1 week before going live.
- SportsRadar free trial has rate limits — sufficient for testing.
- Polymarket FOK (Fill or Kill) orders ensure no partial fills on stale prices.
- The latency window is real but competitive. Low-latency infrastructure (EC2 us-east-1) matters.
- Past performance ≠ future results. This is not financial advice.
