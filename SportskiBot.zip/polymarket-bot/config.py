"""
Configuration — fill in your API keys before running.
Get them from:
  - Telegram Bot:   https://t.me/BotFather
  - Polymarket:     https://docs.polymarket.com (CLOB API key)
  - SportsRadar:    https://developer.sportradar.com (free trial available)
"""

import os

# ─── Telegram ────────────────────────────────────────────────
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
TELEGRAM_CHAT_ID   = os.getenv("TELEGRAM_CHAT_ID",   "YOUR_CHAT_ID_HERE")

# ─── Polymarket ───────────────────────────────────────────────
POLY_API_KEY        = os.getenv("POLY_API_KEY",    "YOUR_POLYMARKET_API_KEY")
POLY_API_SECRET     = os.getenv("POLY_API_SECRET", "YOUR_POLYMARKET_SECRET")
POLY_API_PASSPHRASE = os.getenv("POLY_API_PASSPHRASE", "YOUR_PASSPHRASE")
POLY_WS_URL         = "wss://ws-subscriptions-clob.polymarket.com/ws/market"
POLY_REST_URL       = "https://clob.polymarket.com"

# ─── SportsRadar ─────────────────────────────────────────────
SPORTRADAR_API_KEY  = os.getenv("SPORTRADAR_API_KEY", "YOUR_SPORTRADAR_KEY")
SPORTRADAR_BASE_URL = "https://api.sportradar.us"

# Sports to monitor (add/remove as needed)
ACTIVE_SPORTS = ["soccer", "basketball", "tennis"]

# ─── Trading Parameters ───────────────────────────────────────
PAPER_TRADING       = True          # Set False only when ready for real money
STARTING_BANKROLL   = 100.0         # USD
MAX_KELLY_FRACTION  = 0.06          # Max 6% of bankroll per bet
MIN_EDGE_THRESHOLD  = 0.04          # Only bet if edge > 4%
MIN_BET_USD         = 1.0           # Minimum bet size
MAX_BET_USD         = 50.0          # Hard cap per bet

# ─── Latency / Polling ───────────────────────────────────────
SPORTRADAR_POLL_INTERVAL = 2.0      # seconds between sports API polls
PRICE_STALE_THRESHOLD    = 15.0     # seconds — assume stale if no WS update
EDGE_WINDOW_SECONDS      = 8.0      # seconds to act after edge detected

# ─── Logging ─────────────────────────────────────────────────
LOG_LEVEL = "INFO"
LOG_FILE  = "bot.log"
