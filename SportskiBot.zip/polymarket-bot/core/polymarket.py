"""
core/polymarket.py
──────────────────
Connects to Polymarket CLOB via WebSocket for real-time order book updates.
Also handles REST calls for placing / cancelling orders.
"""

import asyncio
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Dict, Optional, Callable
import websockets
import httpx

from config import (
    POLY_WS_URL, POLY_REST_URL,
    POLY_API_KEY, POLY_API_SECRET, POLY_API_PASSPHRASE,
    PAPER_TRADING
)

logger = logging.getLogger(__name__)


@dataclass
class MarketPrice:
    market_id: str
    token_id: str
    yes_price: float      # Current best ask for YES
    no_price: float       # = 1 - yes_price approximately
    yes_bid: float        # Best bid for YES
    yes_ask: float        # Best ask for YES
    spread: float
    last_updated: float = field(default_factory=time.time)
    is_stale: bool = False


@dataclass  
class OrderResult:
    success: bool
    order_id: Optional[str]
    market_id: str
    side: str             # "YES" or "NO"
    size_usd: float
    price: float
    paper: bool           # True if paper trade
    error: Optional[str] = None


class PolymarketClient:
    def __init__(self, on_price_update: Callable[[MarketPrice], None]):
        self.on_price_update = on_price_update
        self._prices: Dict[str, MarketPrice] = {}
        self._subscribed_markets: set = set()
        self._ws = None
        self._running = False
        self._http = httpx.AsyncClient(timeout=10.0)

    # ─── WebSocket ────────────────────────────────────────────

    async def connect(self):
        self._running = True
        logger.info("Connecting to Polymarket WebSocket...")
        while self._running:
            try:
                async with websockets.connect(POLY_WS_URL) as ws:
                    self._ws = ws
                    logger.info("Polymarket WebSocket connected")
                    
                    # Re-subscribe to all markets on reconnect
                    for market_id in self._subscribed_markets:
                        await self._subscribe(market_id)

                    async for message in ws:
                        await self._handle_message(message)

            except websockets.exceptions.ConnectionClosed:
                logger.warning("Polymarket WS disconnected, reconnecting in 2s...")
                await asyncio.sleep(2)
            except Exception as e:
                logger.error(f"Polymarket WS error: {e}, retrying in 5s...")
                await asyncio.sleep(5)

    async def subscribe_market(self, market_id: str, token_id: str):
        """Subscribe to live price updates for a market."""
        self._subscribed_markets.add(market_id)
        if self._ws:
            await self._subscribe(market_id)

    async def _subscribe(self, market_id: str):
        msg = {
            "type": "subscribe",
            "channel": "market",
            "market": market_id,
        }
        await self._ws.send(json.dumps(msg))
        logger.debug(f"Subscribed to market {market_id}")

    async def _handle_message(self, raw: str):
        try:
            data = json.loads(raw)
            msg_type = data.get("type", "")

            if msg_type == "book":
                await self._process_orderbook(data)
            elif msg_type == "price_change":
                await self._process_price_change(data)
            elif msg_type == "last_trade_price":
                pass  # Can use for trade confirmation

        except json.JSONDecodeError:
            pass
        except Exception as e:
            logger.error(f"Error processing WS message: {e}")

    async def _process_orderbook(self, data: dict):
        market_id = data.get("market", "")
        token_id  = data.get("asset_id", "")
        
        bids = data.get("bids", [])
        asks = data.get("asks", [])

        if not bids or not asks:
            return

        best_bid = float(bids[0]["price"]) if bids else 0.0
        best_ask = float(asks[0]["price"]) if asks else 1.0
        mid      = (best_bid + best_ask) / 2
        spread   = best_ask - best_bid

        price = MarketPrice(
            market_id=market_id,
            token_id=token_id,
            yes_price=mid,
            no_price=round(1 - mid, 4),
            yes_bid=best_bid,
            yes_ask=best_ask,
            spread=spread,
        )
        self._prices[market_id] = price
        self.on_price_update(price)

    async def _process_price_change(self, data: dict):
        # Lightweight update — just update price
        market_id = data.get("market", "")
        price_val = data.get("price")
        if market_id in self._prices and price_val:
            self._prices[market_id].yes_price = float(price_val)
            self._prices[market_id].no_price  = round(1 - float(price_val), 4)
            self._prices[market_id].last_updated = time.time()
            self.on_price_update(self._prices[market_id])

    # ─── REST: Fetch Markets ──────────────────────────────────

    async def search_sports_markets(self, query: str = "soccer") -> list[dict]:
        """Find live sports markets on Polymarket."""
        url = f"{POLY_REST_URL}/markets"
        params = {
            "active": "true",
            "closed": "false",
            "tag_slug": "sports",
            "limit": 50,
        }
        try:
            resp = await self._http.get(url, params=params)
            resp.raise_for_status()
            data = resp.json()
            markets = data.get("data", [])
            # Filter for live/in-play markets
            return [
                m for m in markets
                if any(kw in m.get("question", "").lower() 
                       for kw in ["live", "match", "game", "score", "win"])
            ]
        except Exception as e:
            logger.error(f"Failed to fetch markets: {e}")
            return []

    async def get_market_price(self, market_id: str) -> Optional[float]:
        """REST fallback for current YES price."""
        if market_id in self._prices:
            mp = self._prices[market_id]
            if not mp.is_stale:
                return mp.yes_price
        try:
            url = f"{POLY_REST_URL}/last-trade-price?token_id={market_id}"
            resp = await self._http.get(url)
            resp.raise_for_status()
            return float(resp.json().get("price", 0.5))
        except Exception:
            return None

    # ─── REST: Place Orders ───────────────────────────────────

    async def place_order(
        self,
        token_id: str,
        market_id: str,
        side: str,          # "BUY"
        price: float,       # limit price
        size_usd: float,    # USDC amount
    ) -> OrderResult:
        
        if PAPER_TRADING:
            logger.info(f"[PAPER] BUY {side} on {market_id} @ {price} for ${size_usd}")
            return OrderResult(
                success=True,
                order_id=f"paper_{int(time.time())}",
                market_id=market_id,
                side=side,
                size_usd=size_usd,
                price=price,
                paper=True,
            )

        # Real order via Polymarket CLOB
        try:
            headers = self._auth_headers()
            payload = {
                "token_id": token_id,
                "price": str(price),
                "size": str(size_usd),
                "side": side,
                "type": "LIMIT",
                "time_in_force": "FOK",  # Fill or Kill — important for arb
            }
            resp = await self._http.post(
                f"{POLY_REST_URL}/order",
                json=payload,
                headers=headers,
            )
            resp.raise_for_status()
            data = resp.json()
            
            return OrderResult(
                success=True,
                order_id=data.get("orderID"),
                market_id=market_id,
                side=side,
                size_usd=size_usd,
                price=price,
                paper=False,
            )
        except Exception as e:
            logger.error(f"Order placement failed: {e}")
            return OrderResult(
                success=False,
                order_id=None,
                market_id=market_id,
                side=side,
                size_usd=size_usd,
                price=price,
                paper=False,
                error=str(e),
            )

    def _auth_headers(self) -> dict:
        """HMAC auth headers for Polymarket CLOB."""
        import hmac, hashlib, base64
        ts = str(int(time.time()))
        message = ts + POLY_API_KEY
        sig = hmac.new(
            POLY_API_SECRET.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        return {
            "POLY-API-KEY":        POLY_API_KEY,
            "POLY-SIGNATURE":      sig,
            "POLY-TIMESTAMP":      ts,
            "POLY-PASSPHRASE":     POLY_API_PASSPHRASE,
            "Content-Type":        "application/json",
        }

    def get_cached_price(self, market_id: str) -> Optional[MarketPrice]:
        return self._prices.get(market_id)

    async def disconnect(self):
        self._running = False
        await self._http.aclose()
