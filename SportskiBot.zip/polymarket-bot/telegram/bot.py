"""
telegram/bot.py
───────────────
Telegram bot interface.
- Sends alerts when edges are found
- Allows manual approval or auto-trade mode
- /status, /trades, /pnl, /pause, /resume commands
"""

import asyncio
import logging
import time
from typing import Optional, Callable, Awaitable

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes, MessageHandler, filters
)
from telegram.constants import ParseMode

from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, PAPER_TRADING
from core.edge_detector import TradeSignal
from core.portfolio import PortfolioManager

logger = logging.getLogger(__name__)


class TelegramBot:
    def __init__(
        self,
        portfolio: PortfolioManager,
        on_approve_trade: Callable[[TradeSignal], Awaitable[None]],
        on_reject_trade: Callable[[str], None],
    ):
        self.portfolio = portfolio
        self.on_approve = on_approve_trade
        self.on_reject = on_reject_trade
        
        self._paused = False
        self._auto_trade = False   # Auto-approve all signals
        self._pending_signals: dict[str, TradeSignal] = {}

        self.app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
        self._register_handlers()

    def _register_handlers(self):
        self.app.add_handler(CommandHandler("start",    self._cmd_start))
        self.app.add_handler(CommandHandler("status",   self._cmd_status))
        self.app.add_handler(CommandHandler("trades",   self._cmd_trades))
        self.app.add_handler(CommandHandler("pnl",      self._cmd_pnl))
        self.app.add_handler(CommandHandler("pause",    self._cmd_pause))
        self.app.add_handler(CommandHandler("resume",   self._cmd_resume))
        self.app.add_handler(CommandHandler("auto",     self._cmd_auto))
        self.app.add_handler(CommandHandler("manual",   self._cmd_manual))
        self.app.add_handler(CommandHandler("help",     self._cmd_help))
        self.app.add_handler(CallbackQueryHandler(self._handle_callback))

    async def start(self):
        await self.app.initialize()
        await self.app.start()
        await self.app.updater.start_polling(drop_pending_updates=True)
        logger.info("Telegram bot started")
        await self.send_message(
            f"🤖 *Polymarket Sports Bot Started*\n"
            f"Mode: {'📝 PAPER TRADING' if PAPER_TRADING else '💰 LIVE TRADING'}\n"
            f"Bankroll: ${self.portfolio.bankroll:.2f}\n\n"
            f"Use /help to see commands."
        )

    async def stop(self):
        await self.send_message("🛑 Bot shutting down.")
        await self.app.updater.stop()
        await self.app.stop()
        await self.app.shutdown()

    # ─── Signal Handling ──────────────────────────────────────

    async def notify_signal(self, signal: TradeSignal):
        """Called when edge detector finds a signal."""
        if self._paused:
            return

        if signal.is_expired:
            return

        if self._auto_trade:
            await self.on_approve(signal)
            await self.send_message(
                f"⚡ *AUTO-TRADE PLACED*\n{signal.summary()}",
                parse_mode=ParseMode.MARKDOWN,
            )
            return

        # Manual mode: send with approve/reject buttons
        self._pending_signals[signal.edge.market_id] = signal
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(f"✅ BUY ${signal.bet_usd}", callback_data=f"approve:{signal.edge.market_id}"),
                InlineKeyboardButton("❌ Skip",                    callback_data=f"reject:{signal.edge.market_id}"),
            ]
        ])
        await self.send_message(
            signal.summary(),
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=keyboard,
        )

    async def notify_trade_result(self, trade_id: str, pnl: float, question: str):
        emoji = "✅" if pnl > 0 else "❌"
        await self.send_message(
            f"{emoji} *Trade Settled*\n"
            f"{question[:50]}\n"
            f"P&L: ${pnl:+.2f}",
            parse_mode=ParseMode.MARKDOWN,
        )

    # ─── Callback Handling ────────────────────────────────────

    async def _handle_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        
        action, market_id = query.data.split(":", 1)
        signal = self._pending_signals.pop(market_id, None)

        if action == "approve" and signal:
            if signal.is_expired:
                await query.edit_message_text("⏰ Signal expired before execution.")
                return
            await self.on_approve(signal)
            await query.edit_message_text(f"✅ Trade placed: ${signal.bet_usd} on {signal.market_question[:40]}")
        
        elif action == "reject":
            if signal:
                self.on_reject(market_id)
            await query.edit_message_text("❌ Signal skipped.")

    # ─── Commands ─────────────────────────────────────────────

    async def _cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            "🤖 *Polymarket Sports Bot*\n\nSending you /help now...",
            parse_mode=ParseMode.MARKDOWN,
        )
        await self._cmd_help(update, ctx)

    async def _cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            "📋 *Commands*\n\n"
            "/status — Bot status & mode\n"
            "/pnl — Portfolio P&L summary\n"
            "/trades — Recent trade history\n"
            "/pause — Pause signal detection\n"
            "/resume — Resume signal detection\n"
            "/auto — Switch to auto-trade mode\n"
            "/manual — Switch to manual approval mode",
            parse_mode=ParseMode.MARKDOWN,
        )

    async def _cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        mode = "📝 PAPER" if PAPER_TRADING else "💰 LIVE"
        trade_mode = "⚡ AUTO" if self._auto_trade else "👤 MANUAL"
        paused = "⏸ PAUSED" if self._paused else "▶️ RUNNING"
        pending = len(self._pending_signals)
        
        await update.message.reply_text(
            f"*Bot Status*\n\n"
            f"Trading: {mode}\n"
            f"Mode: {trade_mode}\n"
            f"State: {paused}\n"
            f"Pending signals: {pending}",
            parse_mode=ParseMode.MARKDOWN,
        )

    async def _cmd_pnl(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            f"*Portfolio*\n\n{self.portfolio.portfolio.summary()}",
            parse_mode=ParseMode.MARKDOWN,
        )

    async def _cmd_trades(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        trades = self.portfolio.get_recent_trades(5)
        if not trades:
            await update.message.reply_text("No closed trades yet.")
            return

        lines = ["*Recent Trades*\n"]
        for t in reversed(trades):
            emoji = "✅" if (t.pnl or 0) > 0 else "❌"
            lines.append(
                f"{emoji} {t.question[:35]}...\n"
                f"   P&L: ${t.pnl:+.2f} | {t.side} @ {t.entry_price:.2f}\n"
            )
        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    async def _cmd_pause(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        self._paused = True
        await update.message.reply_text("⏸ Bot paused. Use /resume to restart.")

    async def _cmd_resume(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        self._paused = False
        await update.message.reply_text("▶️ Bot resumed.")

    async def _cmd_auto(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        self._auto_trade = True
        await update.message.reply_text(
            "⚡ *AUTO-TRADE MODE*\nAll signals will be executed automatically.\n"
            "Use /manual to switch back.",
            parse_mode=ParseMode.MARKDOWN,
        )

    async def _cmd_manual(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        self._auto_trade = False
        await update.message.reply_text("👤 Manual mode. You'll approve each trade.")

    # ─── Utility ──────────────────────────────────────────────

    async def send_message(self, text: str, **kwargs):
        try:
            await self.app.bot.send_message(
                chat_id=TELEGRAM_CHAT_ID,
                text=text,
                parse_mode=kwargs.pop("parse_mode", ParseMode.MARKDOWN),
                **kwargs,
            )
        except Exception as e:
            logger.error(f"Telegram send error: {e}")
